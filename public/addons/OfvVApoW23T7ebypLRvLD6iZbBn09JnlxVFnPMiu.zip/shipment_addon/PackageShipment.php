<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PackageShipment extends Model
{
    protected $guarded = [];
    protected $table = 'package_shipment';
}
