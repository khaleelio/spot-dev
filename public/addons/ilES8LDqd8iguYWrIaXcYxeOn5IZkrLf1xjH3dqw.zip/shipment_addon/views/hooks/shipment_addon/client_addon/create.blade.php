<div class="form-group">
    <label>{{translate('Pickup Cost')}}:</label>
    <input type="number" min="0" class="form-control" placeholder="{{translate('Here')}}" name="Client[pickup_cost]" value="0">
</div>