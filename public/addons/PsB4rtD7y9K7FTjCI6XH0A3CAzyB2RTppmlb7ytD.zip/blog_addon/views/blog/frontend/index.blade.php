@extends('backend.layouts.app')

@section('content')

@endsection

@section('modal')

@endsection


@section('script')
    <script type="text/javascript">
        $(document).ready(function(){
            
        });
    </script>
@endsection
