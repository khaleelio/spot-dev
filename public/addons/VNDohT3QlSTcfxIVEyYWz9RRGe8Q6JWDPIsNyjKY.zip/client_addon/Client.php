<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Client extends Model
{
    protected $fillable = ['name','email','responsible_branch_id','responsible_name','responsible_mobile','follow_up_name','follow_up_mobile','national_id','government_id','area','address','how_know_us'];

    public function userClient(){
		return $this->hasOne('App\UserClient', 'client_id' , 'id');
	}
}
