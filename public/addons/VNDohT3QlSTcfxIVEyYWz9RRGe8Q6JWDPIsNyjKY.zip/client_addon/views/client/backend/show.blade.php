@extends('backend.layouts.app')

@section('content')

<div class="aiz-titlebar text-left mt-2 mb-3">
	<div class="row align-items-center">
		<div class="col-md-6">
			<h1 class="h3">{{translate('All Clients')}}</h1>
		</div>
		<div class="col-md-6 text-md-right">
			<a href="{{ route('admin.clients.create') }}" class="btn btn-circle btn-info">
				<span>{{translate('Add New Clients')}}</span>
			</a>
		</div>
	</div>
</div>

<div class="card">
    <div class="card-header">
        <h5 class="mb-0 h6">{{translate('Client Profile')}}</h5>
    </div>
    <div class="card-body">
    <div class="row">
                    <div class="col-sm-6 col-md-4">
                        <img src="<?=uploaded_asset($client->img)?>" width="100%" height="400px" alt="" class="img-rounded img-responsive" />
                    </div>
                    <div class="col-sm-6 col-md-8">
                        <h4>
                        {{$client->name}}</h4>
                       
                        </i></cite></small>
                        <p>
                            <i class="glyphicon glyphicon-envelope"></i>{{$client->email}}
                            <br />
                            <i class="glyphicon glyphicon-phone"></i><a href="tel:{{$client->responsible_mobile}}">{{$client->responsible_mobile}}</a>
                            <br />
                            <i class="glyphicon glyphicon-gift"></i>{{$client->created_at}}</p>
                        <!-- Split button -->
                      
                    </div>
                </div>
    </div>
</div>

@endsection

@section('modal')
    @include('modals.delete_modal')
@endsection
