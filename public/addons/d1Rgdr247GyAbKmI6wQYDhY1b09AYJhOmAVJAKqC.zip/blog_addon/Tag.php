<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App;

class Tag extends Model
{
  protected $fillable = [
      'title'
    ];

}
